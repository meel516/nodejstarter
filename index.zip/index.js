import express from "express";
const app = express();
app.use(express.json());
let list = [];
//health Check endpoint
app.get("/", (req, res) => {
  res.send("Hello, World!");
});
//add item to the list by sending item in the request body
app.post("/add", (req, res) => {
  const { item } = req.body;
  if (item) {
    list.push(item);
    res.status(201).send({ message: "Item added successfully", data: list });
  } else {
    res.status(400).send({ message: "Item is required" });
  }
});
//get all the list items
app.get("/list", (req, res) => {
  res.status(200).json({
    message: "Current list",
    data: list,
  });
});
//update item in the list by sending index and new item in the request body
app.put("/update/:index", (req, res) => {
  const { index } = req.params;
  const { item } = req.body;
  if (index >= 0 && index < list.length && item) {
    list[index] = item;
    res.status(200).send({ message: "Item updated successfully", data: list });
  } else {
    res.status(400).send({ message: "Invalid index or item" });
  }
});
// delet the item by index
app.delete("/delete/:index", (req, res) => {
  const { index } = req.params;
  if (index >= 0 && index < list.length) {
    list.splice(index, 1);
    res.status(200).send({ message: "Item deleted successfully", data: list });
  } else {
    res.status(400).send({ message: "Invalid index" });
  }
});
// get By index
app.get("/list/:index", (req, res) => {
  const { index } = req.params;
  if (index >= 0 && index < list.length) {
    res.status(200).send({ message: "Item found", data: list[index] });
  } else {
    res.status(404).send({ message: "Item not found" });
  }
});
app.listen(3000, () => {
  console.log("Server is running on port 3000");
});
